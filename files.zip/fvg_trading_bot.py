"""
FVG MASTER — Fully Automated Crypto Trading Bot
=================================================
Detects Fair Value Gaps (FVG) on live candle data and trades them
directly on Binance or Bybit via ccxt. Runs independently — no
TradingView required.

⚠️  EDUCATIONAL TEMPLATE — NOT FINANCIAL ADVICE.
⚠️  Automated trading can lose money fast, especially in crypto.
⚠️  ALWAYS run in paper_trading mode first and validate behavior
    before ever pointing this at a real-money account.
⚠️  Use API keys with NO withdrawal permission, IP-whitelisted.

Setup:
    pip install ccxt
    export EXCHANGE_API_KEY="your_key"
    export EXCHANGE_API_SECRET="your_secret"
    python fvg_trading_bot.py
"""

import os
import time
import logging
from dataclasses import dataclass

import ccxt


# ========================= CONFIGURATION =========================
@dataclass
class Config:
    exchange_name: str = "binance"      # "binance" or "bybit"
    symbol: str = "BTC/USDT"
    timeframe: str = "15m"
    paper_trading: bool = True          # ⚠️ keep True until fully validated
    risk_per_trade_pct: float = 1.0     # % of quote balance risked per trade
    rr_ratio: float = 2.0               # reward : risk
    min_gap_atr_mult: float = 0.25      # min FVG size, in multiples of ATR
    atr_period: int = 14
    sl_buffer_atr_mult: float = 0.1
    ema_period: int = 200
    use_trend_filter: bool = True
    poll_seconds: int = 30
    max_candles_fetch: int = 300


CFG = Config()

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    handlers=[logging.FileHandler("fvg_bot.log"), logging.StreamHandler()],
)
log = logging.getLogger("fvg_bot")


# ========================= EXCHANGE SETUP =========================
def build_exchange():
    api_key = os.environ.get("EXCHANGE_API_KEY", "")
    api_secret = os.environ.get("EXCHANGE_API_SECRET", "")
    if not api_key or not api_secret:
        log.warning("No API credentials found in environment variables. "
                    "Set EXCHANGE_API_KEY / EXCHANGE_API_SECRET.")

    if CFG.exchange_name == "binance":
        ex = ccxt.binance({"apiKey": api_key, "secret": api_secret, "enableRateLimit": True})
    elif CFG.exchange_name == "bybit":
        ex = ccxt.bybit({"apiKey": api_key, "secret": api_secret, "enableRateLimit": True})
    else:
        raise ValueError(f"Unsupported exchange: {CFG.exchange_name}")

    if CFG.paper_trading:
        try:
            ex.set_sandbox_mode(True)
            log.info("Sandbox/testnet mode ENABLED (paper trading).")
        except Exception as e:
            log.warning(f"Could not enable sandbox mode for {CFG.exchange_name}: {e}. "
                        f"Bot will still avoid placing real orders if paper_trading=True.")
    return ex


exchange = build_exchange()


# ========================= INDICATORS =========================
def atr(candles, period):
    """candles: list of [ts, open, high, low, close, volume]"""
    if len(candles) < period + 1:
        return None
    trs = []
    for i in range(1, len(candles)):
        h, l, pc = candles[i][2], candles[i][3], candles[i - 1][4]
        trs.append(max(h - l, abs(h - pc), abs(l - pc)))
    return sum(trs[-period:]) / period


def ema(values, period):
    if len(values) < period:
        return None
    k = 2 / (period + 1)
    e = sum(values[:period]) / period
    for v in values[period:]:
        e = v * k + e * (1 - k)
    return e


# ========================= FVG DETECTION =========================
def detect_fvg(candles):
    """
    Returns (fvg_type, gap_top, gap_bottom) for the most recently closed
    3-candle sequence, or (None, None, None) if no gap.
    fvg_type is 'bull', 'bear', or None.
    """
    if len(candles) < 3:
        return None, None, None

    c0, c2 = candles[-3], candles[-1]   # candle i-2 and candle i
    high0, low0 = c0[2], c0[3]
    high2, low2 = c2[2], c2[3]

    a = atr(candles, CFG.atr_period)
    if a is None or a == 0:
        return None, None, None

    if low2 > high0 and (low2 - high0) >= CFG.min_gap_atr_mult * a:
        return "bull", low2, high0          # gap zone: [high0, low2]
    if high2 < low0 and (low0 - high2) >= CFG.min_gap_atr_mult * a:
        return "bear", low0, high2          # gap zone: [high2, low0]
    return None, None, None


# ========================= POSITION SIZING =========================
def calc_position_size(balance_quote, entry, stop):
    risk_amount = balance_quote * (CFG.risk_per_trade_pct / 100)
    risk_per_unit = abs(entry - stop)
    if risk_per_unit <= 0:
        return 0
    return risk_amount / risk_per_unit


def get_balance_quote():
    if CFG.paper_trading:
        # In paper mode without real sandbox funds, simulate a balance.
        return 10_000.0
    bal = exchange.fetch_balance()
    quote_ccy = CFG.symbol.split("/")[1]
    return bal["free"].get(quote_ccy, 0)


# ========================= TRADE EXECUTION =========================
open_position = None  # {"side", "entry", "sl", "tp", "qty"}


def place_trade(side, entry, sl, tp):
    global open_position
    balance = get_balance_quote()
    qty = calc_position_size(balance, entry, sl)
    if qty <= 0:
        log.warning("Position size calculated as 0 — skipping trade.")
        return

    try:
        qty = float(exchange.amount_to_precision(CFG.symbol, qty))
    except Exception:
        pass  # market not loaded yet in dry-run; keep raw qty

    log.info(f"SIGNAL {side.upper()} {CFG.symbol} qty={qty} entry~{entry:.2f} SL={sl:.2f} TP={tp:.2f}")

    if CFG.paper_trading:
        log.info("[PAPER MODE] Order simulated, not sent to exchange.")
        open_position = {"side": side, "entry": entry, "sl": sl, "tp": tp, "qty": qty}
        return

    try:
        if side == "buy":
            exchange.create_market_buy_order(CFG.symbol, qty)
        else:
            exchange.create_market_sell_order(CFG.symbol, qty)
        open_position = {"side": side, "entry": entry, "sl": sl, "tp": tp, "qty": qty}
        log.info("Live order placed.")
    except Exception as e:
        log.error(f"Order failed: {e}")


def manage_open_position(last_price):
    global open_position
    if open_position is None:
        return

    side, sl, tp, qty = (open_position["side"], open_position["sl"],
                          open_position["tp"], open_position["qty"])
    hit_sl = (side == "buy" and last_price <= sl) or (side == "sell" and last_price >= sl)
    hit_tp = (side == "buy" and last_price >= tp) or (side == "sell" and last_price <= tp)

    if not (hit_sl or hit_tp):
        return

    reason = "STOP LOSS" if hit_sl else "TAKE PROFIT"
    closing_side = "sell" if side == "buy" else "buy"

    if CFG.paper_trading:
        log.info(f"[PAPER MODE] Position closed via {reason} at {last_price:.2f}")
        open_position = None
        return

    try:
        if closing_side == "sell":
            exchange.create_market_sell_order(CFG.symbol, qty)
        else:
            exchange.create_market_buy_order(CFG.symbol, qty)
        log.info(f"Closed {side} position via {reason} at {last_price:.2f}")
        open_position = None
    except Exception as e:
        log.error(f"Close order failed: {e}")


# ========================= MAIN LOOP =========================
def fetch_candles():
    limit = max(CFG.ema_period + 5, CFG.max_candles_fetch)
    return exchange.fetch_ohlcv(CFG.symbol, timeframe=CFG.timeframe, limit=limit)


def run():
    log.info(f"Starting FVG bot | {CFG.exchange_name} {CFG.symbol} {CFG.timeframe} "
             f"| paper_trading={CFG.paper_trading}")

    while True:
        try:
            candles = fetch_candles()
            closes = [c[4] for c in candles]
            last_price = closes[-1]

            manage_open_position(last_price)

            if open_position is None:
                fvg_type, gap_top, gap_bottom = detect_fvg(candles)
                trend_ema = ema(closes, CFG.ema_period) if CFG.use_trend_filter else None
                a = atr(candles, CFG.atr_period)

                price_in_zone = (gap_top is not None and gap_bottom <= last_price <= gap_top)

                if fvg_type == "bull" and price_in_zone and a:
                    trend_ok = (not CFG.use_trend_filter) or (trend_ema is not None and last_price > trend_ema)
                    if trend_ok:
                        sl = gap_bottom - CFG.sl_buffer_atr_mult * a
                        risk = last_price - sl
                        tp = last_price + risk * CFG.rr_ratio
                        place_trade("buy", last_price, sl, tp)

                elif fvg_type == "bear" and price_in_zone and a:
                    trend_ok = (not CFG.use_trend_filter) or (trend_ema is not None and last_price < trend_ema)
                    if trend_ok:
                        sl = gap_top + CFG.sl_buffer_atr_mult * a
                        risk = sl - last_price
                        tp = last_price - risk * CFG.rr_ratio
                        place_trade("sell", last_price, sl, tp)

        except Exception as e:
            log.error(f"Loop error: {e}")

        time.sleep(CFG.poll_seconds)


if __name__ == "__main__":
    run()
